Move into the current file path and enter make.

1  Open a new terminal or use the current terminal, enter ./se

2  Open a new terminal enter ./ca or ./cb, ca represent the client of Alice and cb represent the client of Bob

3Open a new terminal enter another command.

