First enter make you will get three ./table
Then enter ./table1 or 2 or 3

Enter the start node. For table1 enter u and for table 2 and 3, enter x
